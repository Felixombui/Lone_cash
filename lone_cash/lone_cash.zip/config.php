<?php
$server='localhost';
$username='root';
$pass='kasarani';
$db='macrasys_lone';
$config=mysqli_connect($server,$username,$pass,$db) or die('Connection failed! Contact Admin.');
?>