<?php
include 'headers.php';
?>
<img src="images/success.png" width="25" height="25" align="left"> Transaction was successful.
<p>
   <div style="text-align: center;"> <a href="index.php"><input type="submit" name="back" value="Ok" style="width:30%;"></a></div>
</p>

<?php
include 'styles.html';
?>