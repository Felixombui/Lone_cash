<?php
include 'headers.php';
?>

<a href="withdraw.php"><div class="itemmenu"><img src="images/bank.png" width="50" height="50"><br>Withdraw</div></a>
<a href="transfer.php"><div class="itemmenu"><img src="images/transfer.png" width="50" height="50"><br>Send Money</div></a>
<a href="deposit.php"><div class="itemmenu"><img src="images/pay.png" width="50" height="50"><br>Deposit From Mpesa</div></a>
<a href="summary.php"><div class="itemmenu"><img src="images/view.png" width="50" height="50"><br>Summary</div></a>

<?php
include 'styles.html'
?>